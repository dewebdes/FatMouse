# BurpBounty-Profiles
Becaute BurpBounty saves bb profiles as singel-line we have to convert it before submit to git</br>
Use convert_bb2multibb.sh for converting to multi-line json 
